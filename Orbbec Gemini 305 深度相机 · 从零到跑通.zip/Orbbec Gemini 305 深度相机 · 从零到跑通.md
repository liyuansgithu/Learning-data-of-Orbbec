# Orbbec Gemini 305 深度相机 · 从零到跑通

> 这篇文档写给第一次接触深度相机的同学。目标是：**看懂它是什么 → 把它接上电脑 → 看到深度图 → 用 Python / ROS2 读出数据**。Gemini 305 和上面两篇的 Gemini 2 / 2L 定位完全不同：它是一颗**给机械臂腕部设计的近距离小相机**。读之前建议先看同仓库《Gemini 2》说明文档，命令通用，本篇重点讲 305 的三个"不一样"：**近（7–50 cm）、小（42×42×23 mm）、没有 IMU**。
> 
> 

- **设备型号**：Orbbec Gemini 305（被动 RGB 双目，MX6800 深度芯片）

- **作者环境**：Windows 11 24H2（x64）\+ 实验室 Ubuntu 22\.04\.4 服务器（ROS2 Humble、Anaconda）

- **版本记录**：OrbbecSDK v2（**注意：305 不支持老 SDK v1**）/ pyorbbecsdk2 2\.1\.0 / OrbbecSDK\_ROS2 v2\-main（以你实测为准，见第 5 节）

## Orbbec Gemini 305是什么

Gemini 305 是一颗**又小又近**的深度相机：机身 4 厘米见方、68 克，专门为**机械臂末端 / 机器人手边 7–50 cm 的近距离**观察设计。和 Gemini 2 系列最大的区别是它用**被动 RGB 双目**——**没有红外投射器**，靠左右两颗彩色相机像人眼一样看纹理算视差。

> 注意⚠️： 因为它"被动"，遇到**纯白无纹理的墙、镜面、透明玻璃**时，会缺深度数据（黑洞）。这一点和 2/2L 的"主动投红外纹理"正好相反，是选型时要记住的关键差异。
> 
> 

![image\.png](图片和附件/image%201.png)

## 设备特性

|**特性**|**说明**|
|---|---|
|极小极轻|42×42×23 mm、68 g，装在机械臂末端不影响动作|
|近距专用|理想工作范围 7–50 cm，正好覆盖"手边那点地方"|
|全局快门彩色|机械臂运动时画面不倾斜，动态抓取稳|
|被动 RGB 双目|两颗彩色相机直接算深度，**不投射红外**（省电、无激光）|
|双彩色流|可以同时输出左右两路彩色图，喂给视觉模型做训练数据|
|硬件降采样|相机内部把高分辨率降为 1/2、1/3、1/4，省 USB 带宽|
|外部触发 / 多机同步|多相机同时采集|

## 规格速查

|**参数**|**值**|**通俗解释**|
|---|---|---|
|深度技术|**被动 RGB 双目**，18 mm 基线|靠画面纹理算距离；无纹理会出黑洞|
|理想工作范围|7–50 cm|常规选型范围，别拿它去测 2 米|
|公开工作范围|4–100 cm|4 cm 只出现在特定低分辨率 \+ 256 像素视差模式|
|深度分辨率/帧率|1280×800 @30 fps；848×530 @60 fps|要 60 fps 用低一档分辨率|
|深度视场|H 88° / V 65° ±3°|近距离下能覆盖一大片操作区域|
|彩色|最高 1280×800 @60 fps，**全局快门**|动态场景好|
|精度|空间精度 ≤1%（50 cm、中心 90%×90% ROI）|特定条件下的典型值|
|深度填充率|≥99\.5%（高反射平面 \+ 规定 ROI）|理想情况；实际看材质|
|IMU|**无**|⚠️ 需要惯性数据要外接 IMU 或用机器人关节反馈|
|接口|USB Type\-C（侧面）|供电\+数据\+同步共用|
|供电|DC 5V、≥700 mA；平均功耗   ≤2\.0 W|很省电，普通 USB 口能带动|
|尺寸/重量|42 × 42 × 23 mm，68 g|三个相机里最小最轻|
|防护|IP54（需 IP54 线缆完全插紧）|裸接口不防水|

**补充：视差搜索范围（近距模式怎么选）**——这是 305 特有参数：

> 换句话说：**"4 cm 超近距"是有条件的**——要切 Close\-Range 预设 \+ 低分辨率 \+ 256 像素视差，还要接受更高的功耗和更低的最高环境温度。常规项目按 7–50 cm 规划就对了。
> 
> 

|**视差搜索范围**|**1280×800 最小 Z**|**848×530 最小 Z**|**640×480 最小 Z**|**温度范围**|**取舍**|
|---|---|---|---|---|---|
|256 像素|50 mm|40 mm|40 mm|\-10–40 ℃|最近，但最耗电、散热要求高|
|128 像素|90 mm|60 mm|55 mm|\-10–45 ℃|均衡，推荐起点|
|64 像素|180 mm|120 mm|110 mm|规格书未单列|最省电，但近处盲区变大|

*说明：视差搜索范围、最小深度与温度（数据源：官方规格书）*

## 认识硬件

### 4\.1 外观与接口

![image\.png](图片和附件/image.png)

设备说明：

- 底部：1 个 1/4\-20 UNC \+ 2 个 M3；背面：2 个 M3（装机械臂末端用）

- Type\-C 在侧面，同时管供电、数据、同步信号

![image\.png](图片和附件/image%202.png)

### 4\.2 安装注意

- 官方建议优先用**随附线缆**；要延长用 USB\-IF 认证线，**控制在 3 m 以内**。

- USB 2\.0 也能连，但 1280×800 深度/彩色会掉到 5–10 fps，**要满帧率必须 USB 3\.0**。

- 装机械臂上时，线缆要预留弯曲空间，别让接头受力。

## 使用前的环境清单

> 与 Gemini 2 Wiki 第 5 节一致，直接复用。
> 
> 注意⚠️： 305 注意：**只支持 Orbbec SDK v2，不支持老版 SDK v1**。任何"SDK v1 支持 305"的旧教程都不要照做。
> 
> 

## 快速上手

### 6\.1 Windows：连接相机 \+ Orbbec Viewer

**Step 1 ：接线**

USB\-C 线连相机和电脑 **USB 3\.0 口**（305 功耗低，普通口就能带，但要满帧率仍建议 USB3\.0）。

**Step 2 ：打开 Viewer**

下载 [Orbbec SDK 下载中心](https://www.orbbec.com/developers/orbbec-sdk/) 的 Windows 版 OrbbecViewer，解压运行。标题栏应显示 `Orbbec Gemini 305 SN:xxxx USB3.2`。

**Step 3 ：打开数据流**

|**按钮/预设**|**正常应该看到**|**说明**|
|---|---|---|
|Depth|伪彩深度图|对着 10–40 cm 内的物体看效果最好|
|Color|彩色画面（全局快门）|纹理|
|Depth\+Color 预设|深度 \+ 彩色同时出|定位/检测用|
|Dual Color 预设|左右两路彩色图|双目数据采集、喂模型用|
|PointCloud|点云|近距离物体轮廓|

### 6\.2 Linux：设备识别 \+ 权限配置

```Bash
lsusb | grep -i 2bc5    *# 确认识别到 Orbbec 设备# 装 udev 规则（装好 pyorbbecsdk2 后执行）*
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"
sudo python <path>/shared/setup_env.py
sudo udevadm control --reload-rules && sudo udevadm trigger
```

### 6\.3 Python：pyorbbecsdk2 读数据

```Bash
conda create -n orbbec python=3.10 -y && conda activate orbbec
pip install --upgrade pyorbbecsdk2
pip show pyorbbecsdk2 | grep Version
```

**枚举设备脚本**——与 Gemini 2 篇一致，直接复用：

```Python
*# enumerate_demo.py —— 确认 SDK 能找到相机*import pyorbbecsdk as ob

*# 1. Context = "相机管理器"*
ctx = ob.Context()

*# 2. 查询设备*
device_list = ctx.query_devices()
count = device_list.get_count()
print(f"[1] 发现 {count} 台 Orbbec 设备")

if count == 0:
    raise RuntimeError("没有找到相机：请检查 USB 线、USB3.0 口、udev 规则")

*# 3. 取第 1 台设备*
device = device_list.get_device_by_index(0)
info = device.get_device_info()
print(f"[2] 型号：{info.get_name()}")
print(f"[3] 序列号：{info.get_serial_number()}")
print("== 枚举成功 ==")
```

**305 特有的"双彩色流"怎么开**：官方示例里预设切换在 Viewer 的预设/配置里做；SDK 侧配置 `Depth+Color` 或 `Dual Color` 预设后，左右彩色流会作为独立帧流输出。用官方示例：

```Bash
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"cd <path>/pyorbbecsdk
python examples/beginner/02_depth_visualization.py   *# 深度可视化# 需要双彩流/其他预设时，看 examples/ 下官方示例和 README 说明*
```

**使用前建议——近距离验证小实验**：手放在相机前 10 cm / 20 cm / 30 cm，用 Viewer 的 Depth 面板读中心深度值，对比卷尺。顺便测一下：移到 2 cm 时深度图是否消失（超出最小 Z，属正常）。

---

### 6\.4 ROS2：Humble 跑起来

与 Gemini 2 篇一致：

```Bash
sudo apt install libgflags-dev nlohmann-json3-dev \
  ros-humble-image-transport ros-humble-image-transport-plugins ros-humble-compressed-image-transport \
  ros-humble-image-publisher ros-humble-camera-info-manager ros-humble-diagnostic-updater \
  ros-humble-diagnostic-msgs ros-humble-statistics-msgs ros-humble-xacro ros-humble-backward-ros \
  libdw-dev libssl-dev mesa-utils libgl1 libgoogle-glog-dev

mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/orbbec/OrbbecSDK_ROS2.git
cd OrbbecSDK_ROS2 && git checkout v2-main
cd ~/ros2_ws
colcon build --event-handlers console_direct+ --cmake-args -DCMAKE_BUILD_TYPE=Release

cd ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/scripts
sudo bash install_udev_rules.sh
sudo udevadm control --reload-rules && sudo udevadm trigger

source ~/ros2_ws/install/setup.bash
ros2 launch orbbec_camera orbbec_camera.launch.py
```

**305 配置文件**：仓库 config 目录已有 `gemini305_dual_color.yaml`（双彩流配置）。默认没匹配时：

```Bash
ls ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/config/
ros2 launch orbbec_camera orbbec_camera.launch.py config_file_path:=gemini305_dual_color.yaml
```

**验证数据流：**

```Bash
ros2 topic list | grep camera
ros2 topic hz /camera/depth/image_raw     *# 期望 ≈30 Hz*
ros2 run rqt_image_view rqt_image_view     *# 查看深度/彩色*
```

## 问题总结（待补充）

## 参考资料

- [Orbbec Gemini 305 中文产品页](https://www.orbbec.com.cn/index/Product/info.html?cate=38&id=75)

- [Orbbec Gemini 305 英文产品页](https://www.orbbec.com/gemini-305/)

- [Gemini 305 Datasheet V1\.0（PDF）](https://orbbec-debian-repos-aws.s3.amazonaws.com/product/Orbbec_Gemini%20305%20Datasheet%20V1.0_20260105.pdf)

- [Gemini 305 文档中心](https://doc.orbbec.com/documentation/Gemini%20305%20Documentation/)

- [OrbbecSDK v2 官方仓库](https://github.com/orbbec/OrbbecSDK_v2)

- [pyorbbecsdk2 官方文档](https://orbbec.github.io/pyorbbecsdk/)

- [OrbbecSDK\_ROS2 官方仓库（v2\-main）](https://github.com/orbbec/OrbbecSDK_ROS2)


# Orbbec Gemini 2 深度相机 · 从零到跑通

这篇文档是写给第一次接触Orbbec Gemini 2深度相机的同学。目标是：**看懂它是什么 → 把它接上电脑 → 看到深度图 → 用 Python / ROS2 读出数据**。全程按"能直接照做"的标准写，命令都给了，照着敲就行。

- **设备型号**：Orbbec Gemini 2（主动双目结构光 3D 相机）

- **作者环境**：Windows 11 24H2（x64）\+ 实验室 Ubuntu 22\.04\.4 服务器（ROS2 Humble、Anaconda）

- **版本记录**：OrbbecSDK v2 / pyorbbecsdk2 2\.1\.0 / OrbbecSDK\_ROS2 v2\-main / 相机固件 1\.4\.60

## Gemini 2 是什么

Gemini 2 是一颗**深度相机**：除了普通相机拍到的彩色画面，它还能给**画面里的每个像素都标一个"离相机多远"的数字**，得到一张"深度图"。

它靠**主动双目结构光**工作：相机自带的红外投影仪往场景里投射人眼看不见的红外纹理，左右两个红外相机同时观察这些纹理，像人眼一样根据"视差"算出距离。所以它在**全黑环境也能测距**，这是它和普通双目相机最大的区别。

**这就好比：**你闭上一只眼再睁开，感觉物体"跳了一下"，物体越近跳得越明显——相机就是用左右两帧图像的差异（视差）来反推距离的。

![image\.png](图片和附件/image%203.png)

![image\.png](图片和附件/image%205.png)

## 设备特性

|**特性**|**说明**|
|---|---|
|主动双目结构光|自己投射红外纹理，弱光/全黑也能测距，室内和半室外都适用|
|宽视场|水平 91°、垂直 66°，一台能覆盖大半张桌子或机器人前方区域|
|深度范围 0\.15–10 m|从"手伸到镜头前"到"3 米外的人"，推荐用 0\.2–5 m 区间|
|一条 USB\-C 搞定一切|供电 \+ 数据传输只用一根线，不额外供电（但电流要够，见踩坑①）|
|硬件 D2C|相机内部直接把深度图对齐到彩色图，省主机算力|
|六轴 IMU|内置加速度计 \+ 陀螺仪，做运动估计、视觉惯性融合的输入|
|多机同步 / 外部触发|多台相机可以"同时按快门"，做多视角 3D 重建|

## 规格速查

|**参数**|**值**|**通俗解释**|
|---|---|---|
|深度技术|主动双目结构光，50 mm 基线|基线越长，远距离越准|
|深度范围|0\.15–10 m（推荐 0\.2–5 m）|超过 5 m 数据可用但精度下降|
|深度分辨率/帧率|1280×800 @30 fps；640×400 @60 fps|想要 60 帧需要"Binned Sparse"模式 \+ USB3\.0|
|深度精度|≤2%（1280×800、2 m、中心 81% ROI）|指特定条件下的相对误差，不代表全场景|
|RGB|1920×1080 @30 fps（卷帘快门）|拍彩色图；快速运动时画面可能"斜"（见踩坑④）|
|IR|1280×800 @30 fps，全局快门|红外的左右两个视角，可用于自定义视觉|
|深度视场|H 91° / V 66° / D 101° ±3°|视野多宽，2 m 距离测得|
|LDP 近距离测距|1–400 mm 单点|极近处（\<15 cm）补一个单点距离，不是整幅深度|
|IMU|100/200/500/1000 Hz 可调|频率越高，运动越快的场景越好用|
|接口|USB Type\-C（USB3\.0/2\.0）\+   8\-Pin 同步口|8\-Pin 用于多机同步/外部触发|
|供电|DC 5V、≥1\.5 A；峰值   \<6\.5 W|插机箱后置 USB 口或带供电的扩展坞更稳|
|尺寸/重量|90 × 25 × 30 mm，约 97 g|比一包纸巾还小，适合装在机器人上|
|工作环境|0–40 ℃，IP5X（防尘不防水）|别淋雨，别放密闭闷热的地方|

*提示：（完整参数见文末官方 Datasheet 链接）*

## 认识硬件

### 4\.1 正面布局

![image\.png](图片和附件/image.png)

实际使用中，我们只需关注三个关键部件即可：

- **LDM**：红外散斑投射器，负责"打光"（不可见红外光）

- **LDP**：独立近距离点测距，物体靠太近时还会自动调暗/关闭激光

- **RGB**：彩色相机，提供纹理

### 4\.2 接口与安装

![image\.png](图片和附件/image%2010.png)

- 日常使用只需要 **Type\-C** 口

- 底部有 1/4\-20 螺孔（标准相机三脚架接口），背面 2 个 M3 孔，装机器人或支架用

![image\.png](图片和附件/image%202.png)

## 使用前的环境清单

### 5\.1 作者环境

|**项目**|**作者版本**|
|---|---|
|操作系统\(Windows\)|Windows 11|
|操作系统\(Linux\)|Ubuntu 22\.04\.4|
|Python|3\.12\.7|
|Anaconda|conda 24\.9\.2|
|pyorbbecsdk2|2\.1\.0|
|ROS2|Humble 2024\-11\-27|
|OrbbecSDK\_ROS2|v2\.10\.6|
|相机固件|1\.4\.60|
|opencv / numpy|opencv 4\.10、numpy 2\.1|

### 5\.2 环境导出命令

```Bash
*# Linux：导出 conda 环境（PyPI 侧的全部依赖都进这一个文件）*
conda env export > environment.yml

*# 或只导出 pip 依赖清单*
pip freeze > requirements.txt

*# ROS2 包清单（确认 orbbec_camera / orbbec_description 在列）*
ros2 pkg list | grep orbbec
```

```PowerShell
*# Windows：导出 pip 清单*
pip freeze > requirements.txt
```

## 快速上手

### 6\.1 Windows：连接相机 \+ Orbbec Viewer

**Step 1：接线**

用包装里带的 USB\-C 线（USB3\.0 线最佳），一头插相机 Type\-C，一头插电脑的 **USB 3\.0 口**。

![b98bb61b189d223ed999e8a17cf45155\_720\.png](图片和附件/b98bb61b189d223ed999e8a17cf45155_720.png)

**Step 2 ：下载并打开 Orbbec Viewer**

1. 打开官方下载页：[Orbbec SDK 下载中心](https://www.orbbec.com/developers/orbbec-sdk/)（也可以在 [OrbbecSDK\_v2 GitHub Releases](https://github.com/orbbec/OrbbecSDK_v2/releases) 里找 `OrbbecViewer_windows_*.zip`），选择[OrbbecSDK\_v2\.10\.6\_win64\.exe](https://github.com/orbbec/OrbbecSDK_v2/releases/download/v2.10.6/OrbbecSDK_v2.10.6_win64.exe)。

![image\.png](图片和附件/image%208.png)

2. 解压，双击运行 `OrbbecViewer.exe`，一路选择默认即可，如果C盘内存不够就安装在D盘目录下。

![image\.png](图片和附件/image%207.png)

注意：电脑首次使用记得先安装驱动 `SensorDrive.exe`

![image\.png](图片和附件/image%206.png)

3. 窗口标题栏（上位机左上角）应显示相机型号和序列号，例如： `Orbbec Gemini2 SN:xxxx USB3.0`

![image\.png](图片和附件/image%204.png)

**Step 3 ：逐个打开数据流**

顶部一排按钮：`彩色` / `深度` / `红外` / `IMU` / `点云`，点一下即开始预览（可显示多窗口）。

|**按钮**|**正常应该看到**|**用途**|
|---|---|---|
|深度|彩色伪彩图，近处偏红/暖色、远处偏蓝/冷色|深度图，核心数据|
|彩色|正常彩色画面|纹理|
|红外|左右两幅灰度红外图|检查散斑投射是否正常|
|IMU|加速度/角速度数值面板，静止时 z≈9\.8 m/s²|惯性数据|
|点云|三维点云（红绿蓝坐标轴）|三维空间点集合|

![image\.png](图片和附件/image%201.png)

![image\.png](图片和附件/image%209.png)

**小知识：深度图怎么读——**Viewer 里 Depth 窗口上方显示就是当前分辨率和帧率；对着物体移动手，深度图颜色会跟着变，说明测距在工作。

### 6\.2 Linux：设备识别 \+ 权限配置

**Step 1 确认系统认出相机**

```Bash
lsusb | grep -i 2bc5
*# 期望输出类似：Bus 001 Device 003: ID 2bc5:xxxx Orbbec*
```

**Step 2 安装 udev 规则（一次性，不装则每次都要 sudo）**

```Bash
*# 用 pyorbbecsdk 自带的脚本（推荐，见 6.3 装好后执行）*
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"*# 记下输出的路径 <path>，然后：*
sudo python <path>/shared/setup_env.py
sudo udevadm control --reload-rules && sudo udevadm trigger

*# 或者用 OrbbecSDK 官方脚本（二选一即可）*cd <你解压的OrbbecSDK目录>/shared
sudo chmod +x install_udev_rules.sh && sudo ./install_udev_rules.sh
sudo udevadm control --reload-rules && sudo udevadm trigger
```

**Step 3 在 Linux 上跑 Viewer**

```Bash
*# 下载 linux x86_64 版 OrbbecViewer zip 并解压*
unzip OrbbecViewer_linux_*.zip -d ~/orbbec_viewer
cd ~/orbbec_viewer
chmod +x OrbbecViewer
./OrbbecViewer
*# 界面操作和 Windows 完全一样：点 Depth / Color / IR / IMU / PointCloud*
```

---

### 6\.3 Python：用 pyorbbecsdk2 读数据（Windows / Linux 通用）

**Step 1 ：建环境并安装**

```Bash
*# Windows (PowerShell) 和 Linux 命令一致，只是激活命令不同*
conda create -n orbbec python=3.10 -y
conda activate orbbec
pip install --upgrade pyorbbecsdk2
pip show pyorbbecsdk2 | grep Version   *# Windows 用：pip show pyorbbecsdk2 | findstr Version*
```

> ⚠️ 注意：从 2\.0\.18 起 PyPI 包名叫 **`pyorbbecsdk2`**（以前叫 `pyorbbecsdk`），但代码里 import 还是 `pyorbbecsdk`。别写错。
> 
> 

**Step 2 ：一次性环境配置（Windows 注册 UVC 元数据 / Linux 装 udev）**

```Bash
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"*# 把输出路径换成 <path>：*
python <path>/shared/setup_env.py     *# Windows 会自动请求管理员权限*
```

**Step 3 ：写第一个程序：枚举设备**

```Python
*# enumerate_demo.py —— 第 1 个程序：确认 SDK 能找到相机*import pyorbbecsdk as ob

*# 1. 创建 Context：可以理解为"相机管理器"，负责连接/枚举设备*
ctx = ob.Context()

*# 2. 查询当前所有连接的相机*
device_list = ctx.query_devices()
count = device_list.get_count()
print(f"[1] 发现 {count} 台 Orbbec 设备")

if count == 0:
    *# 关键报错点：count 为 0 时先查 USB 连接和 udev 规则，不是代码问题*raise RuntimeError("没有找到相机：请检查 USB 线、USB3.0 口、udev 规则")

*# 3. 取第 1 台设备，并打印基本信息*
device = device_list.get_device_by_index(0)
info = device.get_device_info()
print(f"[2] 型号：{info.get_name()}")
print(f"[3] 序列号：{info.get_serial_number()}")
print("== 枚举成功 ==")
```

**逐段讲解**：

- `ob.Context()`：一切操作的入口。多台相机时它统一管理连接状态。

- `query_devices()`：返回设备列表。**为什么先做枚举**——深度相机常见问题就是"代码崩在中间才发现根本没连上设备"，先枚举能最快定位是硬件问题还是代码问题。

- `get_device_by_index(0)`：取第 0 台。多机场景可按序列号 `get_serial_number()` 匹配指定相机，不要依赖顺序。

- `RuntimeError`：主动抛出并提示排查方向，比让程序在别处莫名崩溃更利于排错。

```Bash
python enumerate_demo.py
*# 期望输出：# [1] 发现 1 台 Orbbec 设备# [2] 型号：Gemini 2# [3] 序列号：xxxxxxxx*
```

**Step 4 ：跑官方深度可视化示例**

```Bash
*# 找到 pyorbbecsdk 安装目录下的 examples*
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"cd <path>/pyorbbecsdk
python examples/beginner/02_depth_visualization.py
```

这个示例的流程（理解它，比背代码重要）：

|**官方代码做的事**|**对应概念**|**通俗理解**|
|---|---|---|
|Pipeline \+ Config|数据流管道|像"打开水龙头"，声明要哪些数据流|
|pipeline\.start\(config\)|启动采集|开始一帧一帧地拿数据|
|wait\_for\_frames\(\) 循环|帧循环|每循环一次拿一帧新画面|
|frame\_set\.get\_depth\_frame\(\)|取深度帧|从这一帧里把深度图单独取出来|
|深度转伪彩 \+   cv2\.imshow|可视化|把 16 位距离数值映射成彩色给人眼看|

**关键参数含义**：

- `Format.Y16`：深度原始格式，每个像素是 **16 位无符号整数**，数值 × 缩放系数 = 毫米（如数值 1000 = 1\.0 m）。

- `640×400 @30fps`：低分辨率通常够用且带宽小；要 60fps 需切 Binned Sparse 模式。

- `depth_scale`：深度值单位换算系数，拿到 `get_data()` 的 numpy 数组后**必须乘它**才是真实毫米数，这是新手最容易错的一步。

**可能报错与边界**：

- `DLL load failed / Library not loaded`（Windows）：换成 64 位 Python，装 Visual C\+\+ Redistributable。

- `No device found`（Linux）：没装 udev 规则 → 回到 6\.2 Step 2。

- `No matching distribution`：Python 版本不在 3\.8–3\.13 范围内，换 conda 环境。

---

### 6\.4 ROS2：用 Humble 跑起来

**Step 1 :安装依赖**

```Bash
sudo apt install libgflags-dev nlohmann-json3-dev \
  ros-humble-image-transport ros-humble-image-transport-plugins ros-humble-compressed-image-transport \
  ros-humble-image-publisher ros-humble-camera-info-manager ros-humble-diagnostic-updater \
  ros-humble-diagnostic-msgs ros-humble-statistics-msgs ros-humble-xacro ros-humble-backward-ros \
  libdw-dev libssl-dev mesa-utils libgl1 libgoogle-glog-dev
```

**Step 2: 克隆并编译（v2\-main 分支，基于开源 OrbbecSDK v2）**

```Bash
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/orbbec/OrbbecSDK_ROS2.git
cd OrbbecSDK_ROS2 && git checkout v2-main
cd ~/ros2_ws
colcon build --event-handlers console_direct+ --cmake-args -DCMAKE_BUILD_TYPE=Release
```

**Step 3 :装 udev 规则**

```Bash
cd ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/scripts
sudo bash install_udev_rules.sh
sudo udevadm control --reload-rules && sudo udevadm trigger
```

**Step 4 :启动相机节点**

```Bash
source ~/ros2_ws/install/setup.bash
ros2 launch orbbec_camera orbbec_camera.launch.py
```

> 较新版本会自动识别型号；如果报"找不到配置"，先看有哪些配置：
> 
> ```Bash
> ls ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/config/
> *# 再带上配置文件启动，例如：*
> ros2 launch orbbec_camera orbbec_camera.launch.py config_file_path:=<上面列出的匹配yaml>
> ```
> 
> 

**Step 5 :验证数据流**

```Bash
*# 新开一个终端*source ~/ros2_ws/install/setup.bash

*# 看看相机节点发布了哪些话题*
ros2 topic list | grep camera
*# 期望看到类似：/camera/color/image_raw  /camera/depth/image_raw  /camera/depth/points  /camera/imu# 测深度话题的实际帧率（量化结果！）*
ros2 topic hz /camera/depth/image_raw
*# 期望：average rate: 30.0 左右# 图形化查看*
ros2 run rqt_image_view rqt_image_view
*# 在窗口里选 /camera/depth/image_raw 或 /camera/color/image_raw*
```

## 问题总结

|现象|原因|解决方案|
|---|---|---|
|Viewer 里识别不到相机|供电不足或 USB 带宽不够|<br>换机箱后置 USB3\.0 口，用原装线；笔记本插扩展坞要选带供电的。相机要求   5V/1\.5A<br>|
|快速移动时彩色画面"倾斜"|RGB 是卷帘快门，逐行曝光|静态/慢速场景无影响；高速场景换全局快门型号（如 Gemini 2L）或降低帧率|
|反光/透明/纯黑物体处深度图有黑洞|结构光在这些材质上无法形成可匹配纹理|属正常物理限制，避免对镜面直接测距；必要时用 IR 流辅助判断|
|`ros2 launch` 报找不到 config|不同型号配置文件名不同|`ls .../config/` 后加 `config_file_path:=匹配的yaml`|
|点云/深度有大量噪声点|环境光太强、目标太远或曝光不对|调整曝光、距离目标物 ≤5 m，优先用 Unbinned Dense 模式|

## 参考资料

- [Orbbec Gemini 2 官方产品页](https://www.orbbec.com/products/stereo-vision-camera/gemini-2/)

- [Gemini 2 Datasheet（PDF）](https://d1cd332k3pgc17.cloudfront.net/wp-content/uploads/2023/04/ORBBEC_Datasheet_Gemini-2-2.pdf)

- [OrbbecSDK v2 官方仓库](https://github.com/orbbec/OrbbecSDK_v2)（含 OrbbecViewer 下载）

- [pyorbbecsdk2 官方文档（安装/示例/FAQ）](https://orbbec.github.io/pyorbbecsdk/)

- [OrbbecSDK\_ROS2 官方仓库（v2\-main）](https://github.com/orbbec/OrbbecSDK_ROS2)




# Orbbec Gemini 2L 深度相机 · 从零到跑通

> 这篇文档写给第一次接触深度相机的同学。目标是：**看懂它是什么 → 把它接上电脑 → 看到深度图 → 用 Python / ROS2 读出数据**。Gemini 2L 是 Gemini 2 系列里的"长基线版"，和Gemini 2 的区别在于：**基线从 50 mm 加长到 100 mm，看得更远、远距离更准，机身也更宽**。读之前建议先看同仓库的《Gemini 2》说明文档，命令基本通用，本文只介绍 2L 的特有部分。
> 
> 

- **设备型号**：Orbbec Gemini 2L（100 mm 长基线主动双目结构光 3D 相机）

- **作者环境**：Windows 11 24H2（x64）\+ 实验室 Ubuntu 22\.04\.4 服务器（ROS2 Humble、Anaconda）

- **版本记录**：OrbbecSDK v2 / pyorbbecsdk2 2\.1\.0 / OrbbecSDK\_ROS2 v2\-main

## Orbbec Gemini 2L是什么

Gemini 2L 和 Gemini 2 是同一家族，做同一件事：**给画面里每个像素标上"离相机多远"**。不同的是它的两个红外相机分得**更开（基线 100 mm）**，就像人眼间距更宽的人"看远处更有把握"——所以 2L 的深度范围更远（0\.2–10 m），远距离精度更好，代价是机身更宽、功耗更高。

另外它有一个很多人忽略的亮点：**RGB 相机也是全局快门**，拍快速运动的物体不会"画面倾斜"，做动态抓取、移动机器人比 Gemini 2 更稳。

> 类比：Gemini 2 是"普通双眼"，2L 是"开得更开的双眼"——看得远、看得准，但头也更大。
> 
> 

![image\.png](图片和附件/image%201.png)

## 设备特性

|**特性**|**说明**|
|---|---|
|100 mm 长基线|远距离（3–7 m）深度质量明显好于 50 mm 基线的 Gemini 2|
|主动双目结构光|自己投射 850 nm 红外纹理，全黑环境也能测距|
|全局快门 RGB \+ IR|高速运动不畸变，适合移动机器人、动态抓取|
|深度范围 0\.2–10 m|理想工作区 0\.25–7 m，比 Gemini 2 更偏"远"|
|Dimensioning 测量模式|官方专门为三维扫描/尺寸测量准备的模式|
|六轴 IMU|加速度计 \+ 陀螺仪，100–1000 Hz 可调|
|多机同步 / 外部触发|星型或链型拓扑，多相机同时采集|

## 规格速查

|**参数**|**值**|**通俗解释**|
|---|---|---|
|深度技术|主动双目结构光，100 mm 基线|长基线 = 远距离更准|
|深度范围|0\.20–10 m（理想 0\.25–7 m）|10 m 是可测边界，7 m 内质量更好|
|深度分辨率/帧率|1280×800 @30 fps；640×400 @60 fps|60 fps 仅限 Binned Sparse 模式|
|深度精度|RMSE \<2% @4 m（1280×800、中心81% ROI、反射率\>80%）|4 m 处平面的实测指标，不代表全量程|
|RGB|1280×800 @30 fps，**全局快门**|动态场景不倾斜，这是 2L 的卖点|
|RGB 视场|H94°/V68°/D104°|比深度视场略宽，D2C 覆盖更足|
|深度视场|H91°/V66°/D101° ±3°|与 Gemini 2 相同|
|LDP 近距测距|1–400 mm 单点|极近处补单点距离，非稠密深度|
|IMU|100/200/500/1000 Hz|频率越高越适合快速运动|
|接口|USB Type\-C（USB3\.0/2\.0）\+   8\-Pin 同步口|Type\-C 供电\+数据一体|
|供电|DC 5V、≥2\.0 A；峰值   \<10 W|**比 Gemini 2 更耗电**，注意供电|
|尺寸/重量|124 × 29 × 26 mm，约 144 g|比 Gemini 2 长 1/3，安装要预留空间|
|工作环境|0–40 ℃，IP5X（防尘不防水）|别淋雨，会坏|

## 认识硬件

### 4\.1 正面布局

![image\.png](图片和附件/image.png)

### 4\.2 安装注意（差异点）

- 底部 1/4\-20 UNC 螺孔，背部固定孔：**官方产品页写 2×M3，但英文规格书 V1\.7 标的是 2×M4**。做支架开模前一定要拿实物确认，这是最容易踩的坑。

- 被动散热，外壳别紧贴热源。

![image\.png](图片和附件/image%202.png)

## 使用前的环境清单

> 与 Gemini 2 Wiki 第 5 节**完全一致**，请读者自己跑一遍并测试真实版本。直接复用那套命令即可，这里不做重复赘述。
> 
> 

## 快速上手

### 6\.1 Windows：连接相机 \+ Orbbec Viewer

**Step 1 ：接线**

用 USB\-C 线连接相机和电脑 **USB 3\.0 口**。⚠️ 2L 供电要求 **5V/2A**（Gemini 2 是 1\.5A），笔记本 Type\-C 口或廉价扩展坞可能喂不饱，建议插台式机后置 USB3\.0 口或带独立供电的 Hub。

**Step 2 ：打开 Viewer**

下载 [Orbbec SDK 下载中心](https://www.orbbec.com/developers/orbbec-sdk/) 的 Windows 版 OrbbecViewer，解压运行 `OrbbecViewer.exe`。窗口标题栏应显示 `Orbbec Gemini 2L SN:xxxx USB3.2`。

**Step 3 ：逐个打开数据流**

|**按钮**|**正常应该看到**|**用途**|
|---|---|---|
|Depth|伪彩深度图（近暖远冷）|核心数据|
|Color|正常彩色画面（全局快门）|纹理|
|IR Left / IR Right|左右两幅灰度红外图|检查散斑|
|IMU|加速度/角速度面板|惯性数据|
|PointCloud|三维点云|空间点集合|

### 6\.2 Linux：设备识别 \+ 权限配置

与 Gemini 2 完全一致：

```Bash
lsusb | grep -i 2bc5    *# 确认系统识别到 Orbbec 设备# 装 udev 规则（装好 pyorbbecsdk2 后执行，二选一）*
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"
sudo python <path>/shared/setup_env.py
sudo udevadm control --reload-rules && sudo udevadm trigge
```

### 6\.3 Python：pyorbbecsdk2 读数据

```Bash
conda create -n orbbec python=3.10 -y && conda activate orbbec
pip install --upgrade pyorbbecsdk2
pip show pyorbbecsdk2 | grep Version
```

**枚举设备脚本**——和 Gemini 2 篇一致，直接复用：

```Python
*# enumerate_demo.py —— 确认 SDK 能找到相机*import pyorbbecsdk as ob

*# 1. Context = "相机管理器"：负责连接、枚举设备*
ctx = ob.Context()

*# 2. 查询当前所有连接的相机*
device_list = ctx.query_devices()
count = device_list.get_count()
print(f"[1] 发现 {count} 台 Orbbec 设备")

if count == 0:
    *# 常见坑：count 为 0 多半是 USB 连接或 udev 权限问题，不是代码问题*raise RuntimeError("没有找到相机：请检查 USB 线、USB3.0 口、udev 规则")

*# 3. 取第 1 台设备并打印信息*
device = device_list.get_device_by_index(0)
info = device.get_device_info()
print(f"[2] 型号：{info.get_name()}")
print(f"[3] 序列号：{info.get_serial_number()}")
print("== 枚举成功 ==")
```

```Bash
python enumerate_demo.py
*# 期望输出：发现 1 台 Orbbec 设备 / 型号：Gemini 2L / 序列号：xxxx*
```

**再跑官方可视化示例看深度图：**

```Bash
python -c "import pyorbbecsdk, os; print(os.path.dirname(pyorbbecsdk.__file__))"cd <path>/pyorbbecsdk
python examples/beginner/02_depth_visualization.py
```

**2L 特有提示**：想验证"长基线远距离优势"，可以把相机放到 3–5 m 外拍一面墙，和 Gemini 2 同场景对比深度图的噪点密度——这就是能写进 Wiki 的实测对比数据（加分项）。

---

### 6\.4 ROS2：Humble 跑起来

与 Gemini 2 篇一致，直接复用命令：

```Bash
*# 依赖（一次性）*
sudo apt install libgflags-dev nlohmann-json3-dev \
  ros-humble-image-transport ros-humble-image-transport-plugins ros-humble-compressed-image-transport \
  ros-humble-image-publisher ros-humble-camera-info-manager ros-humble-diagnostic-updater \
  ros-humble-diagnostic-msgs ros-humble-statistics-msgs ros-humble-xacro ros-humble-backward-ros \
  libdw-dev libssl-dev mesa-utils libgl1 libgoogle-glog-dev

*# 克隆 + 编译*mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/orbbec/OrbbecSDK_ROS2.git
cd OrbbecSDK_ROS2 && git checkout v2-main
cd ~/ros2_ws
colcon build --event-handlers console_direct+ --cmake-args -DCMAKE_BUILD_TYPE=Release

*# udev*cd ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/scripts
sudo bash install_udev_rules.sh
sudo udevadm control --reload-rules && sudo udevadm trigger

*# 启动*source ~/ros2_ws/install/setup.bash
ros2 launch orbbec_camera orbbec_camera.launch.py
```

**2L 配置文件**：仓库 config 目录里已有 `gemini2L_dual_ir.yaml`（双红外配置）。如果默认启动没自动匹配：

```Bash
ls ~/ros2_ws/src/OrbbecSDK_ROS2/orbbec_camera/config/
ros2 launch orbbec_camera orbbec_camera.launch.py config_file_path:=gemini2L_dual_ir.yaml
```

**验证数据流：**

```Bash
ros2 topic list | grep camera
ros2 topic hz /camera/depth/image_raw     *# 期望 ≈30 Hz*
ros2 run rqt_image_view rqt_image_view     *# 选深度/彩色话题查看*
```

## 问题总结（待补充）

## 参考资料

- [Orbbec Gemini 2L 官方产品页](https://www.orbbec.com/products/stereo-vision-camera/gemini-2l/)

- [Gemini 2 Series Datasheet V1\.7（PDF）](https://d1cd332k3pgc17.cloudfront.net/wp-content/uploads/2023/07/Orbbec-Gemini-2-Series-DatasheetPublicV1.720240316.pdf)

- [OrbbecSDK v2 官方仓库](https://github.com/orbbec/OrbbecSDK_v2)

- [pyorbbecsdk2 官方文档](https://orbbec.github.io/pyorbbecsdk/)

- [OrbbecSDK\_ROS2 官方仓库（v2\-main）](https://github.com/orbbec/OrbbecSDK_ROS2)



